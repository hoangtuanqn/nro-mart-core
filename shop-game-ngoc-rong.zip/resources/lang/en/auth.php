<?php
return [
    'failed' => 'Thông tin đăng nhập không chính xác.',
    'password' => 'Mật khẩu không đúng.',
    'throttle' => 'Bạn đã đăng nhập sai quá nhiều lần. Vui lòng thử lại sau :seconds giây.',
];