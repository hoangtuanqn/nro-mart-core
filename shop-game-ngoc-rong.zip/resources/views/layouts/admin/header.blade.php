<div class="header">

    <div class="header-left active" style="display: flex; justify-content: center;">
        <a href="{{ route('admin.index') }}" class="logo">
            <img src="https://imgur.com/hIFVXRo.png" alt="Logo">
        </a>
        <a href="index.html" class="logo-small">
            <img src="https://i.imgur.com/J46gSIO.png" alt="Logo">
        </a>
        <a id="toggle_btn" href="javascript:void(0);">
        </a>
    </div>

    <a id="mobile_btn" class="mobile_btn" href="#sidebar">
        <span class="bar-icon">
            <span></span>
            <span></span>
            <span></span>
        </span>
    </a>
</div>
